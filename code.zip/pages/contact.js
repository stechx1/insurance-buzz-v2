import { ContactHero } from '@/components/ContactHero/ContactHero';

const Contact = () => {
  return (
    <div>
      <ContactHero />
    </div>
  );
};

export default Contact;
